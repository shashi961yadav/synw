package com.ammson.snyw;

/**
 * Created by GopalReddy on 3/6/2018.
 */

public class AppConfig
{
    // Server user login url
    public static String URL_LOGIN = "http://183.82.98.52:85/SnYW/android_login_api/login.php";

    // Server user register url
    public static String URL_REGISTER = "http://183.82.98.52:85/SnYW/android_login_api/register.php";

}
